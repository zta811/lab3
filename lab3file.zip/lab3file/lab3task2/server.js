const {User}= require('./modles')

const express = require("express")

const app = express()

app.use(express.json())

app.get('/',async(req,res)=>{
    const users = await User.find()
    res.send(users)})

app.post('/register',async(req,res)=>{
const user = await User.create({
username:req.body.username,
password:req.body.password,

})

    res.send(user)
})

app.post('/register',async(req,res)=>{
    const user = await User.create({
    username:req.body.username,
    password:req.body.password,
    
    })
    
        res.send(user)
    })
    app.post('/login',async(req,res)=>{
        const user = await User.findOne({
        username:req.body.username
      
       
        
        
        
        })
        if(!user){
return res.status(422).send({ message:'account is not exist'})

        }

       const istrue  = require('bcrypt').compareSync(req.body.password,user.password)
       if(!istrue){


        return res.status(422).send({ message:'fake password'})


       }
    
            res.send(user)
        
        
        })

     

      

app.listen(3333, () => {
    console.log("http://localhost:3333");
  });