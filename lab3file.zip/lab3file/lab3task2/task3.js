const express = require("express");
const bodypaser = require("body-parser")

const app= express();
const port = 3002;


   console.log("is works in " + port)
app.listen(port,function(){



 
})



app.get('/about',function(trq,res){

res.send("this is a next")

}



)

app.get('/',function(req,res){

res.sendFile(__dirname+"/index.html")

});
app.get('/todo',function(req,res){

   res.sendFile(__dirname+"/todo.html")
   
   });
app.post("/register",function(req,res){
res.redirect("/")


});
app.post("/login",function(req,res){
   console.log("i see");
   res.redirect("/todo")
   
   
   });


   app.post("/logout",function(req,res){
      console.log("i see");
      res.redirect("/")
      
      
      });
   