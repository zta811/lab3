const mongoose =require('mongoose')

mongoose.connect("mongodb://localhost:27017/pr2", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
})
const userschema = new mongoose.Schema({
  username:{ type:String,unique:true},
  password:{ type:String,set(val){
return require('bcrypt').hashSync(val,15)
  }
},
  })
const User = mongoose.model('User',userschema)

const objectvalue =new mongoose.Schema({
objectname:{type:String},


})
const Object =mongoose.model('object',objectvalue)
module.exports = { Object }

//User.db.dropCollection('users')

module.exports = { User }

