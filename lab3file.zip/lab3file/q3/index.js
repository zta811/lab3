const express=require("express");
const bodyparser=require("body-parser");
const app =express();
app.use(bodyparser.urlencoded({extended:true}));
app.use(express.static(__dirname+"/todo"));
app.set('views', './src/views');
app.set('views', __dirname + '/views');
app.set("view engine","ejs");
const port =3232;
app.listen(port,function(){
console.log("port is"+ port)

})


app.get('/todo',function(req,res){
var string1 =" todo list";
var username ="zta"
res.render("index",{myString:string1,
        myname:username})


});