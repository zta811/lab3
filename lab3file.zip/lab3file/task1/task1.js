const { table } = require("console");
const fs = require("fs");

var user1 = {username:"aab",password:"12344"};
var user2 = {username:"bbc",password:"12344"};
var user3 = {username:"cdde",password:"12344"};
var user4 = {username:"hhh",password:"12344"};


var object1 ={
    _id:"1",
    name :"eat",
	owner:"user1" ,
    creator :"user2",
	done :"yes",
    cleared:"no"
    

} 
var object2 ={
    _id:"2",
    name :"eat",
	owner:"user2" ,
    creator :"user2",
	done :"yes",
    cleared:"no"
    

} 
var object3 ={
    _id:"3",
    name :"eat",
	owner:"user1" ,
    creator :"user2",
	done :"no",
    cleared:"no"
    

} 
var object4 ={
    _id:"4",
    name :"eat",
	owner:"user2" ,
    creator :"user2",
	done :"no",
    cleared:"no"
    

} 
var object5 ={
    _id:"5",
    name :"eat",
	owner:"TAB" ,
    creator :"user2",
	done :"no",
    cleared:"no"
    

} 
var mystring1 =JSON.stringify(object1);
var mystring2 =JSON.stringify(user1);
fs.appendFileSync(__dirname+"/object.json",mystring1,"utf8",function(err){
    if(err){



console.log(err);


}}
  );
  fs.appendFileSync(__dirname+"/user.json",mystring2,"utf8",function(err){
      if(err){



    console.log(err);
    
    
    }}
      );
console.log("user list")
console.log(JSON.stringify(user1))
console.log(JSON.stringify(user2))
console.log(JSON.stringify(user3))
console.log(JSON.stringify(user4))
console.log("object list")
console.log(JSON.stringify(object1))
console.log(JSON.stringify(object2))
console.log(JSON.stringify(object3))
console.log(JSON.stringify(object4))
console.log(JSON.stringify(object5))
